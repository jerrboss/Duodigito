package org.duodigito.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

private data class Question(
    val word: String,
    val prompt: String,
    val options: List<String>,
    val answer: String,
    val note: String
)

class MainActivity : Activity() {
    private val lessons = listOf(
        Question("АЗЪ", "Что означает слово «азъ»?", listOf("Я", "Ты", "Он"), "Я",
            "«Азъ» это первое лицо единственного числа. Конечный ъ характерен для традиционного написания."),
        Question("ГЛАГОЛАТИ", "Выбери значение глагола «глаголати».", listOf("Говорить", "Идти", "Слышать"), "Говорить",
            "Глаголати значит говорить или произносить слова."),
        Question("АЩЕ", "Что значит «аще»?", listOf("Если", "Сегодня", "Вместе"), "Если",
            "«Аще» часто встречается в церковнославянских библейских и богослужебных текстах."),
        Question("НЫНѢ", "Как перевести «нынѣ»?", listOf("Теперь, ныне", "Вчера", "Завтра"), "Теперь, ныне",
            "Буква ѣ называется ять. В произношении и чтении учитывай традицию и учебный источник."),
        Question("МИРЪ", "Какое значение может иметь «миръ»?", listOf("Мир, покой или вселенная по контексту", "Только река", "Только дом"), "Мир, покой или вселенная по контексту",
            "Значение церковнославянского слова определяется контекстом. Не своди его к одному современному значению."),
        Question("СЕ", "Что означает «се» в книжном языке?", listOf("Вот, смотри", "Никогда", "Потом"), "Вот, смотри",
            "Указательная частица «се» встречается в старых текстах."),
        Question("БЛАГО", "С чем связано слово «благо»?", listOf("Добро, доброе", "Снег", "Огонь"), "Добро, доброе",
            "Слово входит в множество церковнославянских сочетаний, например «благословити»."),
        Question("СЛОВО", "Что значит «слово»?", listOf("Слово, речь", "Вода", "Земля"), "Слово, речь",
            "Написание похоже на современное русское слово, но грамматика и значение в контексте могут отличаться."),
        Question("РАБЪ", "Как обычно понимается «рабъ Божий» в молитвенном тексте?", listOf("Слуга Божий", "Учитель", "Князь"), "Слуга Божий",
            "Это традиционное религиозное выражение. При переводе важно учитывать контекст и жанр."),
        Question("ГОСПОДИ", "Какова функция формы «Господи» в обращении?", listOf("Звательная форма", "Множественное число", "Будущее время"), "Звательная форма",
            "В церковнославянском сохраняются звательные формы обращения, например «Господи».")
    )

    private val parchment = Color.rgb(248, 244, 230)
    private val ink = Color.rgb(43, 48, 39)
    private val green = Color.rgb(53, 79, 58)
    private val prefs by lazy { getSharedPreferences("duodigito_progress", MODE_PRIVATE) }
    private var index = 0
    private var score = 0
    private var answered = false
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun setup() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(parchment)
            setPadding(22, 20, 22, 18)
        }
        val header = TextView(this).apply {
            text = "☦  DUODIGITO"
            textSize = 23f
            setTextColor(green)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        root.addView(header)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 4, 0, 16)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun text(value: String, size: Float, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(ink)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(4, 9, 4, 9)
        }

    private fun button(value: String, action: () -> Unit): Button =
        Button(this).apply {
            text = value
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(green)
            setOnClickListener { action() }
            val p = LinearLayout.LayoutParams(-1, -2)
            p.setMargins(0, 6, 0, 6)
            layoutParams = p
        }

    private fun showHome() {
        setup()
        content.addView(text("Церковнославянский язык в поморской старообрядческой традиции", 25f, true))
        content.addView(text("Изучай буквы, слова и формы языка по шагам. Приложение работает офлайн.", 17f))
        content.addView(text("Путь обучения", 20f, true))
        content.addView(text("Урок 1. Первые слова", 18f, true))
        content.addView(text("10 коротких заданий с пояснениями и подсчётом результата.", 16f))
        content.addView(button("Начать урок", { index = 0; score = 0; showQuestion() }))
        content.addView(text("Твой лучший результат: ${prefs.getInt("best_score", 0)} из ${lessons.size}", 16f, true))
        content.addView(text("О традиции", 19f, true))
        content.addView(text("Поморское согласие относится к беспоповским направлениям старообрядчества. Его культурная история связана, в частности, с Выговской пустынью и изучением старых церковных книг. Этот курс использует базовые примеры церковнославянского, а не объявляет отдельную «поморскую грамматику».", 15f))
        content.addView(text("Примечание: это ранний учебный прототип. До публикации все примеры нужно сверить с конкретными старопечатными изданиями и специалистом по церковнославянскому языку.", 14f))
    }

    private fun showQuestion() {
        answered = false
        setup()
        val q = lessons[index]
        content.addView(text("УРОК 1  •  ЗАДАНИЕ ${index + 1} ИЗ ${lessons.size}", 14f, true))
        content.addView(text(q.word, 32f, true))
        content.addView(text(q.prompt, 21f, true))
        val feedback = text("", 16f)
        q.options.forEach { option ->
            content.addView(button(option) {
                if (!answered) {
                    answered = true
                    val correct = option == q.answer
                    if (correct) score++
                    feedback.text = (if (correct) "Верно. " else "Ответ: ${q.answer}. ") + q.note
                    content.addView(feedback)
                    content.addView(button(if (index == lessons.lastIndex) "Завершить урок" else "Далее") {
                        if (index < lessons.lastIndex) { index++; showQuestion() } else showResult()
                    })
                }
            })
        }
        content.addView(text("Очки за урок: $score", 15f))
    }

    private fun showResult() {
        val best = maxOf(score, prefs.getInt("best_score", 0))
        prefs.edit().putInt("best_score", best).apply()
        setup()
        content.addView(text("Урок завершён", 28f, true))
        content.addView(text("Правильных ответов: $score из ${lessons.size}", 21f))
        content.addView(text("Лучший результат: $best из ${lessons.size}", 17f))
        content.addView(text(if (score >= 8) "Доброе начало. Продолжай чтение и повторяй слова." else "Повтори урок, чтобы закрепить значения и формы.", 17f))
        content.addView(button("Повторить урок") { index = 0; score = 0; showQuestion() })
        content.addView(button("На главную") { showHome() })
    }
}
